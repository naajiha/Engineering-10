#ENGR10
#Lab3
#Naajiha Mushayeed
#nam225@lehigh.edu
from gpiozero import CamJamKitRobot #imports the cam jam library
from time import sleep

myRobot = CamJamKitRobot()

myRobot.forward(.5)
sleep(2)
myRobot.stop()
