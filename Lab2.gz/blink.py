#ENGR10
#Lab 2
#Naajiha Mushayeed
#nam225@lehigh.edu
from gpiozero import LED
from time import sleep

led = LED(23)

while True:
	led.on()
	sleep(1)
	led.off()
	sleep(1)

