#ENGR10
#Lab 2
#Naajiha Mushayeed
#nam225@lehigh.edu

from gpiozero import LED
from time import sleep

led1 = LED(23)
led2 = LED(24)
led3 = LED(25)

while True:
	led1.on()
	sleep(1)

	led1.off()
	sleep(1)
	led2.on()
	sleep(1)

	led1.on()
	sleep(1)
	
	led2.off()
	sleep(1)
	led1.off()
	sleep(1)
	led3.on()
	sleep(1)

	led1.on()
	sleep(1)
	
	led1.off()
	sleep(1)
	led2.on()
	sleep(1)

	led1.on()
	sleep(1)

	led1.off()
	sleep(1)
	led2.off()
	sleep(1)
	led3.off()
	sleep(1)
